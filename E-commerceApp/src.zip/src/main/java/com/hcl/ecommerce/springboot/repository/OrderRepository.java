package com.hcl.ecommerce.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.ecommerce.springboot.entity.ProductOrder;

public interface OrderRepository extends JpaRepository<ProductOrder, Integer> {

}
